// First go through Hashing from pics (9-12-2023)
// collision in Hashing and further collision subtypes
#include<iostream>
using namespace std;
// TOWER OF HANOI function implementation  (sour=source , aux = auxillary , des = destination)
void TOH(int n , char sour , char aux , char des)
{
	if(n==1)
	{
		cout<<"Move Disk "<<n<<" from "<<sour<<" to "<<des<<endl;
	}
	else
	{
		TOH(n-1 , sour , des , aux);
		cout<<"Move Disk "<<n<<" from "<<sour<<" to "<<des<<endl;
		TOH(n-1 , aux , sour , des);
	}
}
int main()
{
	int n;
	cout<<"Enter number of Disks : ";
	cin>>n;
	// calling the TOH
	TOH(n,'A','B','C');
	return 0;
}
