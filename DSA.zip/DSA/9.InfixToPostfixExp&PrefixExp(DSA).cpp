#include<iostream>
using namespace std;
#include<string.h>>
class convertexp
{
	public:
	char stack[100];
	int top=-1;
	
	void push(char ch)
	{
		top++;
		stack[top]=ch;
	}
	
	char pop()  // to return something we use char
	{
		int last = top;
		top--;
		return stack[last];
	}
	
	bool isempty()
	{
		if(top==-1)
		{
			cout<<"\nUnderFlow";
			return true;
		}
		else
		{
			return false;
		}
	}
	
	getprecedence(char op)
	{
		if(op=='^') //power
		{
			return 3;
		}
		else if(op=='*' || op=='/')
		{
			return 2;
		}
		else if(op=='+' || op=='-')
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	bool isoperator(char ch)
	{
		if(ch=='*'|| ch=='/' || ch=='^' || ch=='+'  || ch=='-')
		{
			return true;
		}
		return false;
	}
	
	void infixtopostfix(char infix_exp[] , char postfix_exp[])
	{
		push('(');
		strcat(infix_exp,")");   //string concatenation
		// (A*(B+D)/E-F*(G/K))   <= Example
		
		char i_ch;
		int i=0 , post_index=0;;
		while(infix_exp[i]!='\0')
		{
			i_ch=infix_exp[i];
			cout<<"\nInfix expression : "<<i_ch;
			if(i_ch=='(')
			{
				push('(');
			}
			else if(i_ch==')')   // i_ch=infix character,,,, s_ch = stack character
			{
				char s_ch;
				s_ch = pop();
				while(s_ch!='(')
				{
					postfix_exp[post_index]=s_ch;    // add operator into postfix expression
					post_index++;
					s_ch = pop();
				}								
			}
			else if(isoperator(i_ch))  //   +,-,^,*,/;    if precedence is bigger then add it into stack or if precednece is equal or lesser then 
											// stack[top] then place that sign in stack and  move previous smaller or equal sign from stack into expresssion 
			{
				if(getprecedence(i_ch) > getprecedence(stack[top]))   // check operator precedence
				{
					push(i_ch);
				}
				else
				{ 
					do
					{
						char s_ch = pop();  // remove add operators (lower precedence) from stack
						postfix_exp[post_index]=s_ch;    // add operator into postfix expression
						post_index++;
					}while(getprecedence(i_ch) <= getprecedence(stack[top]));
					
					push(i_ch); // add operator in stack;
				}
			}
			else ///operand like A,B,C,D...... it is always added in postfix expression
			{
				postfix_exp[post_index]=i_ch;
				post_index++;
			}
			
			i++; // get next index of infix expression
		}
		postfix_exp[post_index]='\0';  // to end the expression
	}
	
	void infixtoprefix(char infix_exp[] , char prefix_exp[])
	{
		//step 1     reverse the bracket
		strrev(infix_exp);
		int i=0;
		while(infix_exp[i]!='\0')
		{
			if(infix_exp[i]=='(')
			{
				infix_exp[i]=')';
			}
			else if(infix_exp[i]==')')
			{
				infix_exp[i]='(';
			}
			i++;
		}
		//step 2        same upper procedure
		char postfix_exp[100];
		infixtopostfix( infix_exp,postfix_exp);
		
		//step 3     reverse the expression
		strrev(postfix_exp);
		
		// step 4       copy the expression
		strcpy(prefix_exp , postfix_exp);
	}
};
int main()
{
	convertexp ex;
	char infix_exp[100] , prefix_exp[100] , postfix_exp[100];
	cout<<"Enter infix Expression : ";   // expression in by user or written by user
	cin>>infix_exp;
	ex.infixtopostfix( infix_exp,postfix_exp);
	cout<<"\nPostfix Expression : "<<postfix_exp;   // after
	
	cout<<"\nEnter infix Expression : "; // expression in by user or written by user
	cin>>infix_exp;
	ex.infixtoprefix( infix_exp,prefix_exp);
	cout<<"\nPrefix Expression : "<<prefix_exp;  // before
	
}



