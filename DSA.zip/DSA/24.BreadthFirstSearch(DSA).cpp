// in form of queue
#include<stdio.h>
#define QUEUE_SIZE 20
#define MAX 20
//queue
int queue[QUEUE_SIZE];  // function prototype
int queue_front , queue_end; // function prototype
void enqueue(int v);  // function prototype
int dequeue();   // function prototype

void bfs(int adj[][MAX] , int n , int source);

int main()
{
	// adj matrix
	int adj[][MAX] = {
		{0,1,1,1},
		{1,0,1,0},
		{1,1,0,1},
		{1,0,1,0},
	};
	
	int n = 4 ;// no of vertex or node and egde is path
	int starting_vertex = 3;
	
	bfs(adj , n , starting_vertex);  // breadth first search
	
	return 0;
}

void bfs(int adj[][MAX] , int n , int source)
{
	// variables
	int i , j;
	// visited array to flag the vertex that were visited
	int visited[MAX];
	// queue
	queue_front=0;
	queue_end=0;
	// set visited for all vertex to 0(means unvisited) 
	for(int i=0; i< MAX ; i++)
	{
		visited[i] = 0;
	}
	// mark the visited source
	visited[source] = 1;
	// enqueue visited vertex
	enqueue(source);
	// print the vertex as result
	printf("%d" , source);
	// continue till queue is not empty
	while(queue_front <= queue_end)
	{
		// dequeue first element from the queue
		i=dequeue();
		
		for(int j=0 ; j<n ; j++) // it is visited array
		{
			if(visited[j] == 0 && adj[i][j]==1)
			{
				// mark vertex are visited
				visited[j] = 1;
				// push vertex into stack
				enqueue[j];
				// print the vertex as result
				printf("%d" , j);
			}
		}
	}
	printf("\n");
}

void enqueue(int v)
{
	queue[queue_end] = v;
	queue_end++;
}

int dequeue()  // int is used because we have to return value
{
	int index = queue_front;
	queue_front++;
	return queue[index];
}
