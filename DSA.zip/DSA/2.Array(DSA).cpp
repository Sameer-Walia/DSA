
#include<iostream>
using namespace std;
class array
{
		int *a,lb,ub,index;  // lower bound , upper bound
		public:
			array()
			{
				// int n[5];  static memory allocation which is already given
				
				int n;
				cout<<"Enter Size of Array : ";
				cin>>n;
				a=new int [n];// dynamic memory allocation given by user
				lb=0;
				ub=n-1;
				index=-1;// no element in array
			}
			void InsertionAtEnd()
			{
//				int e;
//				cout<<"enter elements to insert : "<<endl;
//				cin>>e;
				if(index>=ub)  //(-1>4)n==5,up=4 ,after adding 1 from else it become (0>4)
				{
					cout<<"overflow\n";
				}
				else   // (-1+1=0) add elemet at index 0 , (0+1=1) add elemet at index 1
				{
					int e;
					cout<<"enter elements to insert : "<<endl;
					cin>>e;
					index++;
					a[index]=e;
					cout<<"element inserted successfully\n"<<endl;
				}
			}
			void InsertionAtPosition()
			{
				if(index>=ub)  
				{
					cout<<"overflow\n";
					return;                   // another way unlike InsertionAtEnd()......not to use else
				}
				
				int pos,el,i;
				cout<<"Enter Position : ";
				cin>>pos;
				pos--;
				if(pos<lb || pos >index)
				{
					cout<<"\nWrong Position\n";
				}
				else
				{
					//pos--;
					cout<<"\nEnter Element : ";
					cin>>el;
					
					for(i=index ; i>=pos ; i--)
					{
						a[i+1]=a[i];
					}
					a[pos] = el;
					index++;
					
					cout<<"\nElement Inserted Successfully\n";
				}
			}
			void deletion()
			{
				if(index<lb)
				{
					cout<<"\nUnderflow";
				}
				else
				{
					index--;
					cout<<"\nElement Deleted Successfully";
				}
			}
			void deletionPos()
			{
				if(index<lb)
				{
					cout<<"\nUnderflow";
				}
				else
				{
					int pos,i;
					cout<<"Enter Position : ";
					cin>>pos;
					pos--;
					for(i=pos ; i<ub ; i++)
					{
						a[i]=a[i+1];
					}
					index--;
					cout<<"\nElement Deleted Successfully";
				}
			}
			void linearsort()
			{
				int i,j,temp;
				for(i=lb ; i<index ; i++)
				{
					for(j=i+1 ; j<=index ; j++)
					{
						if(a[i]>a[j])
						{
							temp=a[i];
							a[i]=a[j];
							a[j]=temp;
						}
					}
				}
				cout<<"\nElement sorted successfully";
			}
			int linearsearch(int key)
			{
				int i;
				for(i=lb ; i<=index ; i++)
				{
					if(key==a[i])
					{
						return i;
					}
				}
				return -1;
			}
			void traversing()
			{
				if(index<lb)
				{
					cout<<"underflow\n";
				}
				else
				{
					cout<<"==========ELEMENT LIST=============\n";
					int i;
					for(i=lb ; i<=index ; i++)
					{
						cout<<"\n"<<a[i];
					}
				}
			}
};
int main()
{
	int ch;
	array a1;
	//while(1)
	while(true)//infinte loop(we can stop it with the help of break)
	{
		cout<<"\n==================================";
		cout<<"\n1.Insert At End";
		cout<<"\n2.Insert At Given Position";
		cout<<"\n3.Deletion";
		cout<<"\n4.Deletion At Given Position";
		cout<<"\n5.Linear Sorting";
		cout<<"\n6.Linear Searching";
		cout<<"\n7.Traversing";
		cout<<"\n8.Exit";
		cout<<"\nEnter Choice : ";
		cin>>ch;
		if(ch==1)
		{
			a1.InsertionAtEnd();
		}
		else if(ch==2)
		{
			a1.InsertionAtPosition();
		}
		else if(ch==3)
		{
			a1.deletion();
		}
		else if(ch==4)
		{
			a1.deletionPos();
		}
		else if(ch==5)
		{
			a1.linearsort();
		}
		else if(ch==6)
		{
			int key;
			cout<<"\nEnter Element To Search : ";
			cin>>key;
			int loc = a1.linearsearch(key);
			if(loc==-1)
			{
				cout<<"\nElement Not Found\n";
			}
			else
			{
				cout<<"Element Found At Location "<<loc+1;
			}
		}
		else if(ch==7)
		{
			a1.traversing();
		}
		else if(ch==8)
		{
			cout<<"Exiting......";
			break;
		}
		else
		{
			cout<<"\nWrong Choice\n";
		}
	}
	
	return 0;
}
