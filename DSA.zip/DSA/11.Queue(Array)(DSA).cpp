#include<iostream>
using namespace std;
class queue
{
	// it follows fifo ( first in first out )
	int *a,rear,front,maxsize;
	public:
		queue()
		{
			cout<<"Enter Total Size Of Queue : ";
			cin>>maxsize;
			a = new int [maxsize];
			rear=-1;
			front=-1;
		}
		bool isempty()
		{
			if(front==-1)
			{
				cout<<"\nUnderFlow";
				return true;
			}
			return false;
		}
		bool isfull()
		{
			if(rear==(maxsize-1))
			{
				cout<<"\nOverFlow";
				return true;
			}
			return false;
		}
		void enqueue()
		{ 
			if(isfull()==true)   //if(isfull())
			{
				return;
			}
			int el;
			cout<<"Enter a Element : ";
			cin>>el;			
			if(front==-1) // no element in queue
			{
				front++;
				rear++;
			}
			else
			{
				rear+=1;
			}
			a[rear]=el;
			cout<<"\nElement Inserted Successfully";
		}
		void dequeue()
		{
			if(isempty()==true)  //if(isempty())
			{
				return;
			}
			cout<<"Element removed "<<a[front]<<" successfully";
			if(front==rear || front==(maxsize-1))
			{
				front=-1;
				rear=-1;
			}
			else
			{
				front++;
			}	
		}
		void traversing()
		{
			if(isempty()==true)
			{
				return ;
			}
			cout<<"\n=======QUEUE=========\n";
			for(int i=front; i<=rear ; i++)
			{
				cout<<a[i]<<" => ";
			}
			cout<<endl;
		}
};
int main()
{
	queue obj;
	int ch;
	while(1)
	{
		cout<<"\n=====Options========";
		cout<<"\n1.Enqueue";
		cout<<"\n2.Dequeue";
		cout<<"\n3.Traversing";
		cout<<"\n4.Exit";
		cout<<"\nEnter Choice : ";
		cin>>ch;
		if(ch==1)
		{
			obj.enqueue();
		}
		else if(ch==2)
		{
			obj.dequeue();
		}
		else if(ch==3)
		{
			obj.traversing();
		}
		else if(ch==4)
		{
			cout<<"\nExiting....";
			break;
		}
		else
		{
			cout<<"Wrong Choice..";
		}		
	}
	return 0;
}
