// in form of stack
#include<stdio.h>
#define STACK_SIZE 20
#define MAX 20

void dfs(int adj[][MAX] , int n , int source);

int main(void)
{
	// adj matrix
	int adj[][MAX] = {
		{0,1,1,1},
		{1,0,1,0},
		{1,1,0,1},
		{1,0,1,0},
	};
	
	int n = 4 ;// no of vertex or node and egde is path
	int starting_vertex = 3;
	
	dfs(adj , n , starting_vertex);   // depth first search
	
	return 0;
}

void dfs(int adj[][MAX] , int n , int source)
{
	// variables
	int i , j;
	bool change=false;
	
	// visited array to flag the vertex that were visited
	
	int visited[MAX];
	// top of stack
	int tos=0;
	// stack
	int stack[MAX];
	
	// set visited for all vertex to 0(means unvisited) 
	for(int i=0; i< MAX ; i++)
	{
		visited[i] = 0;
	}
	// mark the visited source
	visited[source] = 1;
	// push the vertex into stack
	stack[tos] = source;
	
	// print the vertex as result
	printf("%d" , source);
	// continue till stack is not empty
	while(tos >=0 )
	{
		// to check if any vertex was marked as visited
		change = false;
		// get vertex at the top of stack
		i= stack[tos];
		
		for(int j=0 ; j<n ; j++)
		{
			if(visited[j]==0 && adj[i][j]==1)
			{
				// mark vertex as visisted
				visited[j] = 1;
				
				// push vertex into stack
				
				tos++;
				stack[tos] = j;
				// print the vertex as result
				
				printf("%d" , j);
				//vertex visited
				change=true;
				break;
			}
		}
		if(change==false)
		{
			tos--;
		}
	}
	printf("\n");
}

