#include<iostream>
using namespace std;
class array
{
		int *a,lb,ub,index;
		public:
			array()
			{
				// int n[5];  static memory allocation which is already given
				
				int n;
				cout<<"enter size of array : ";
				cin>>n;
				a=new int [n];// dynamic memory allocation given by user
				lb=0;
				ub=n-1;
				index=0;// no element in array
			}
			void InsertionAtEnd()
			{
				int el;
				cout<<"Enter element : ";
				cin>>el;
				if(index > ub)
				{
					cout<<"\overflow";
				}
				else
				{
				
					a[index]=el;
					index++;
					cout<<"Element inserted successfully\n\n";
				}
				
			}
			void traversing()
			{
				int i;
				cout<<"\n===========Element List============\n";
				for(i=0; i<index ;i++)      // for(i=0; i<=ub;i++)
				{
					cout<<"\n"<<a[i];
				}
				
			}
};
int main()
{
	int ch;
	array a1;
	
	a1.InsertionAtEnd();
	a1.InsertionAtEnd();
	a1.InsertionAtEnd();
	a1.traversing();
	return 0;
}
