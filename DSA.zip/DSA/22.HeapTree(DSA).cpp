//==================HEAP TREE====================
// parent node should be greater than child nodes
// child node should always be smaller than parent node
// on deleting root node(parent or first node) , smaller element from last will come at first(root or parent node)
// and then compare parent node(smaller element which come from last) it with its child node(left and right)
// then replace root or parent node(smaller element which we take from last) with bigger child node , do again and agian till end or null
#include<iostream>
using namespace std;
class MaxHeapSort
{
	int heap[100];
	int maxsize;
	int curr;
	public:
	MaxHeapSort()
	{
		maxsize=99;
		curr=-1;
	}
	void insertion()
	{
		int val;
		cout<<"Enter value to be insert : ";
		cin>>val;
		if(curr==maxsize)
		{
			cout<<"\nOverFlow";
		}
		else
		{
			curr++;
			heap[curr]=val;
			reheapup();
			cout<<"\n"<<val<<" inserted successfully";
		}
	}
	void reheapup()
	{
		int i = curr;
		int temp;
		int parent=(i-1)/2;
		while(i!=0 || heap[parent] > heap[i])
		{
			if(heap[parent] < heap[i])
			{
				// swapping
				temp =heap[parent];
				heap[parent] = heap[i];
				heap[i] = temp;
			}
			i=parent;
			parent = (i-1)/2;
		}
	}
	void traversing()
	{
		if(curr==-1)
		{
			cout<<"\nEmpty Heap";
		}
		else
		{
			cout<<"\nMax Heap Sort Elements are : \n";
			for(int i=0; i<=curr;i++)
			{
				cout<<heap[i]<<" ";
			}
		}
	}
	void deletion()
	{
		if(curr==-1)
		{
			cout<<"\nUnderflow";
		}
		else
		{
			heap[0]=heap[curr];
			curr--;
			reheapdown();
			cout<<"\nRoot deleted successfuly";
		}
	}
	void reheapdown()
	{
		int left,right,i,j,temp;
		i=0; // root node
		while(i<=curr)
		{
			left=(2*i)+1;
			right=(2*i)+2;
			if(left>curr)
			{
				// checking left child not exists(no child)
				// do nothing;
				break;
			}
			else if(right > curr)
			{
				// checking right child not exists(1 child (left one)
				j=left;
			}
			else
			{
				// both exists
				if(heap[left] > heap[right])
				{
					j=left;	
				}
				else
				{
					j=right;
				}
			}
			if(heap[i] < heap[j]) // checking with greater child
			{
				temp = heap[i];
				heap[i] = heap[j];
				heap[j]= temp;
				i=j;
			}
			else
			{
				break;
			}
		}
	}
	
};
int main()
{
	MaxHeapSort t1;
	int ch;
	while(true)
	{
		cout<<"\n----Options-----";
		cout<<"\n1.Insertion";
		cout<<"\n2.Deletion";	
		cout<<"\n3.Display";	
		cout<<"\n4.Exit";
		cout<<"\nEnter choice : ";
		cin>>ch;
		if(ch==1)
		{
			t1.insertion();
		}
		else if(ch==2)
		{
			t1.deletion();
		}
		else if(ch==3)
		{
			t1.traversing();
		}
		else if(ch==4)
		{
			cout<<"\nExiting";
			break;
		}
		else
		{
			cout<<"\nWrong choice....";
		}
	}
	return 0;
}
