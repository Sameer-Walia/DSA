#include<iostream>
using namespace std;
struct node
{
	int info;
	struct node *next;
};
class stack // it follows LIFO  (last in first out)
{
	struct node *top;
	public:
		stack()
		{
		   top=NULL;
		}
		struct node *createnode()
		{
			struct node *mynode = new struct node;
			if(mynode==NULL)
			{
				cout<<"\nUnderflow";
			}
			return mynode;
		}

		bool isempty()
		{
			if(top==NULL)
			{
				cout<<"\nUnderflow";
				return true;
			}
			return false;
		}
		void push()
		{
			int info;
			cout<<"Enter info : ";
			cin>>info;
			struct node *newnode = createnode();
			newnode->info=info;
			if(top==NULL)
			{
				top = newnode;
				newnode->next=NULL;
			}
			else
			{
				newnode->next=top;
				top=newnode;
			}
			cout<<"Element "<<info<<" pushed successfully";
			
		}
		void pop()
		{
			if(isempty())
			{
				return;
			}
			struct node *temp1 , *temp2;
			temp1=top; // first node
			temp2=temp1->next; // second node
			top=temp2;
			
			cout<<"Element "<<temp1->info<<" popped successfully";
			delete temp1;
			
			
		}
		void peek()
		{
			if(isempty())
			{
				return;
			}
			cout<<"\nElement at top is "<<top->info;
		}
		void traversing()
		{
			if(isempty())
			{
				return;
			}
			cout<<"\n==============Stack===================\n";
			struct node *temp;
			temp = top;
			while(temp!=NULL)
			{
				cout<<temp->info<<"\n";
				temp = temp->next;
			}
		}
};
int main()
{
	int ch;
	stack s1;
	while(true)
	{
		cout<<"\n====================================";
		cout<<"\n1.Push";
		cout<<"\n2.Pop";
		cout<<"\n3.Peek";
		cout<<"\n4.Traversing";
		cout<<"\n5.Exit";
		cout<<"\nEnter Choice : ";
		cin>>ch;
		if(ch==1)
		{
			s1.push();
		}
		
		else if(ch==2)
		{
			s1.pop();
		}
		else if(ch==3)
		{
			s1.peek();
		}
		else if(ch==4)
		{
			s1.traversing();
		}
		else if(ch==5)
		{
			cout<<"\nExiting....";
			break;
		}
		else
		{
			cout<<"Wrong Choice";
		}
	}
	return 0;
}
