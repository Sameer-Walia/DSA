#include<iostream>
using namespace std;
class stack // it follows LIFO  (last in first out)
{
	int *a;
	int maxsize , top;
	public:
		stack()
		{
		    maxsize=5;
			a=new int[maxsize];
			top=-1;
		}
		bool isfull()
		{
			if(top>=(maxsize-1))
			{
				cout<<"\nOverflow";
				return true;
			}
			return false;
		}
		bool isempty()
		{
			if(top==-1)
			{
				cout<<"\nUnderflow";
				return true;
			}
			return false;
		}
		void push()
		{
			if(isfull()==true)
			{
				return;
			}
			int el;
			cout<<"Enter Element : ";
			cin>>el;
			top++;
			a[top]=el;
			cout<<"Element "<<el<<" pushed successfully";
		}
		void pop()
		{
			if(isempty()) // (isempty()==true)
			{
				return;
			}
			cout<<"Element "<<a[top]<<" popped successfully";
			top--;  // delete
		}
		void peek()  // to see the element which is at top
		{
			if(isempty())
			{
				return;
			}
			cout<<"\nTop element is "<<a[top];
		}
		void traversing()
		{
			if(isempty())
			{
				return;
			}
			int i;
			for(i=top;i>=0;i--)
			{
				cout<<a[i]<<endl;
			}
		}
};
int main()
{
	int ch;
	stack s1;
	while(true)
	{
		cout<<"\n====================================";
		cout<<"\n1.Push";
		cout<<"\n2.Pop";
		cout<<"\n3.Peek";
		cout<<"\n4.Traversing";
		cout<<"\n5.Exit";
		cout<<"\nEnter Choice : ";
		cin>>ch;
		if(ch==1)
		{
			s1.push();
		}
		
		else if(ch==2)
		{
			s1.pop();
		}
		else if(ch==3)
		{
			s1.peek();
		}
		else if(ch==4)
		{
			s1.traversing();
		}
		else if(ch==5)
		{
			cout<<"\nExiting....";
			break;
		}
		else
		{
			cout<<"Wrong Choice";
		}
	}
	return 0;
}
