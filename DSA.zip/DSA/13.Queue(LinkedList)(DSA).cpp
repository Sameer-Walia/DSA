#include<iostream>				 
using namespace std;
struct node
{
	int info;
	struct node *next;	
};
class Queuelinkedlist
{
	// it follows FIFO
	struct node *front , *rear;
	public: 
		Queuelinkedlist()
		{
			front=NULL;
		}
		struct node *createnode()   // it means available space to make list and starting point where we insert our
									// first number and then that number will become head
		{
			//int a=new int [n]         --------------   below same code is use 
			struct node *mynode = new struct node;
			if(mynode==NULL)   // means is there any space avialable , if no then overflow or underflow
			{
				cout<<"overflow";
			}
			return mynode;
		}
		void enqueue()
		{
			int info;
			struct node *newnode = createnode();
			cout<<"Enter Info : ";
			cin>>info;
			
			newnode->info=info;
			newnode->next=NULL;
						
			if (front==NULL)		// head is starting pint or called start pointer....
			{
				front=rear=newnode;
				cout<<"First element inserted";
			}
			else
			{
				
				rear->next=newnode;
				rear=newnode;	
				cout<<"\nElement "<<newnode->info<<" inserted at last";	
			}
			
		}

		void dequeue()
		{
			if(front==NULL)
			{
				cout<<"underflow";
			}
			else
			{
				struct node *temp1 , *temp2;
				temp1 = front ;///fist node
				temp2 = temp1->next;  //second node
				
				front = temp2;
				
				cout<<"Element "<<temp1->info<<" deleted successfully";
				delete temp1; //de-allocate memory
				
				if(temp2==NULL) // when only one node is left
				{
					rear=NULL;	
				}
			}
		}
		
		void traversing()
		{
			if(front==NULL)
			{
				cout<<"\nUnderflow";
				return;
			}
			else
			{
				struct node *temp;
				temp=front;   // start from first node;
				
				while(temp!=NULL) // till Null of last node
				{
					cout<<temp->info<<" -> ";
					temp=temp->next;
				}				
			}
		}
	
};
int main()
{
	int ch;
	Queuelinkedlist a1;
	while(true)
	{
		cout<<"\n==================================";
		cout<<"\n1. Enqueue";
		cout<<"\n2. Dequeue";
		cout<<"\n3. Traversing";
		cout<<"\n4. Exit";
		cout<<"\nEnter Choice : ";
		cin>>ch;
		if(ch==1)
		{
			a1.enqueue();
		}
		else if(ch==2)
		{
			a1.dequeue();
		}
		else if(ch==3)
		{
			a1.traversing();
		}
		else if(ch==4)
		{
			cout<<"Exiting......";
			break;
		}
		else
		{
			cout<<"\nWrong Choice\n";
		}
	}
	
	return 0;
}


